# by digiteng...11.2020
# <widget render="NachtClockPixmap" source="global.CurrentTime" path="/usr/share/enigma2/Nacht/clockneon/" position="1470,980" size="293,77" zPosition="5" backgroundColor="#ff000000" alphatest="blend" transparent="1" />
from Renderer import Renderer
from enigma import ePixmap, eTimer, ePoint, eWidget, loadPNG, eSize
from datetime import datetime

class NachtClockPixmap(Renderer):

	def __init__(self):
		Renderer.__init__(self)

		self.vol_timer = eTimer()
		self.vol_timer.callback.append(self.pollme)
		
	GUI_WIDGET = eWidget
	def applySkin(self, desktop, screen):
		attribs = self.skinAttributes[:]
		for attrib, value in self.skinAttributes:
			if attrib == 'position':
				self.x = int(value.split(',')[0])
				self.y = int(value.split(',')[1])
			elif attrib == 'size':
				self.szX = int(value.split(',')[0])
				self.szY = int(value.split(',')[1])
			elif attrib == 'path':
				self.path = value
		self.skinAttributes = attribs
		ret = Renderer.applySkin(self, desktop, screen)

	def changed(self, what):
		if not self.suspended:
			now = datetime.now()
			clk = now.strftime("%H:%M")
			clk0 = clk[0]
			clk1 = clk[1]
			# clk2 = clk[2]
			clk3 = clk[3]
			clk4 = clk[4]

			szx, szy = self.szX/4, self.szY
			
			
			self.c0.setPixmap(loadPNG(self.path + "{}.png".format(str(clk0))))
			self.c0.resize(eSize(szx, szy))
			self.c0.move(ePoint(0,0))
			self.c0.setZPosition(5)
			self.c0.setTransparent(1)
			self.c0.setAlphatest(2)
			self.c0.show()
			
			self.c1.setPixmap(loadPNG(self.path + "{}.png".format(str(clk1))))
			self.c1.resize(eSize(szx, szy))
			self.c1.move(ePoint(szx,0))
			self.c1.setZPosition(5)
			self.c1.setTransparent(1)
			self.c1.setAlphatest(2)
			self.c1.show()
			
			# self.c2.setPixmap(loadPNG(self.path + "{}.png".format(str(clk1.replace(":","blink")))))
			# self.c2.resize(eSize(70,77))
			# self.c2.move(ePoint(140,0))
			# self.c2.setZPosition(5)
			# self.c2.setAlphatest(2)
			# self.c2.show()
			
			self.c3.setPixmap(loadPNG(self.path + "{}.png".format(str(clk3))))
			self.c3.resize(eSize(szx, szy))
			self.c3.move(ePoint(szx*2+5,0))
			self.c3.setZPosition(5)
			self.c3.setTransparent(1)
			self.c3.setAlphatest(2)
			self.c3.show()

			self.c4.setPixmap(loadPNG(self.path + "{}.png".format(str(clk4))))
			self.c4.resize(eSize(szx, szy))
			self.c4.move(ePoint(szx*3+5,0))
			self.c4.setZPosition(5)
			self.c4.setTransparent(1)
			self.c4.setAlphatest(2)
			self.c4.show()

	def GUIcreate(self, parent):
		self.instance = eWidget(parent)
		self.c0 = ePixmap(self.instance)
		self.c1 = ePixmap(self.instance)
		# self.c2 = ePixmap(self.instance)
		self.c3 = ePixmap(self.instance)
		self.c4 = ePixmap(self.instance)

	def pollme(self):
		self.changed(None)
		return

	def onShow(self):
		self.suspended = False
		self.vol_timer.start(200)

	def onHide(self):
		self.suspended = True
		self.vol_timer.stop()
